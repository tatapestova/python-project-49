#!/usr/bin/env python3

import games.logics
import games.game_brain_even


def main():
    games.game_brain_even.is_even()


if __name__ == '__main__':
    main()
