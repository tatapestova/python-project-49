# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/tatapestova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatapestova/python-project-49/actions)\n\n### Codeclimate maintainability:\n<a href="https://codeclimate.com/github/tatapestova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/832bd8344ecad800d99c/maintainability" /></a>\n\n**"BRAIN GAMES"** is a set of five console games based on popular mobile brain training apps. Every game starts with a welcome set and game-questions. The game is considered to be completed after **3 correct answers**. If the user gives a wrong answer the game is end. \n\n### GAME "IS EVEN?"\n\nA random number is shown. The user needs to answer "yes" if the number is even or "no" if it\'s odd. \n\n```bash\n$ brain-even\n```\n\n[![asciicast](https://asciinema.org/a/y616PGN4pRKfnqF0ZTQNjxF7D.svg)](https://asciinema.org/a/y616PGN4pRKfnqF0ZTQNjxF7D)\n\n### GAME "CALCULATOR"\n\nA random arithmetic expression is shown. The user needs to answer the question: "What is the result of the expression?".\n\n```bash\n$ brain-calc\n```\n\n[![asciicast](https://asciinema.org/a/xXp3tJDBgyI7dxKdimj2Iqbac.svg)](https://asciinema.org/a/xXp3tJDBgyI7dxKdimj2Iqbac)\n\n### GAME "GREATEST COMMON DIVISOR"\n\nTwo random numbers are shown. The user needs to find the greatest common divisor of given numbers.\n\n```bash\n$ brain-gcd\n```\n\n[![asciicast](https://asciinema.org/a/qWjmBlkEwVs5hgYRs6tGPp5ec.svg)](https://asciinema.org/a/qWjmBlkEwVs5hgYRs6tGPp5ec)\n\n### GAME "ARITHMETIC PROGRESSION"\n\nA set of numbers is shown which is an arithmetic progression. One of the numbers is replaced by 2 dots. The user needs to answer the question: "What number is missing in the progression?".\n\n```bash\n$ brain-progression\n```\n\n[![asciicast](https://asciinema.org/a/5aVmWF7SVOjj6ZeeAFR7415EZ.svg)](https://asciinema.org/a/5aVmWF7SVOjj6ZeeAFR7415EZ)\n\n### GAME "IS PRIME?"\n\nA random number is shown. The user needs to answer "yes" if the number is prime or "no" if it\'s not. \n\n```bash\n$ brain-prime\n```\n\n[![asciicast](https://asciinema.org/a/dxAPtQutzcdl4NVtGy5MInCC9.svg)](https://asciinema.org/a/dxAPtQutzcdl4NVtGy5MInCC9)',
    'author': 'hextet',
    'author_email': 'info@hexlet.io',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
