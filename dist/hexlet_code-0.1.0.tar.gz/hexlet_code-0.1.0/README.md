### Hexlet tests and linter status:
[![Actions Status](https://github.com/tatapestova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatapestova/python-project-49/actions)

### Codeclimate maintainability:
<a href="https://codeclimate.com/github/tatapestova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/832bd8344ecad800d99c/maintainability" /></a>

### Demo on asciinema:

| Game | Asciinema |
| ------ | ------ |
| Brain-even | https://asciinema.org/a/IHKaQXwG14Eu6uwP2UAwMpcn1 |
| Brain-calc | https://asciinema.org/a/IHKaQXwG14Eu6uwP2UAwMpcn1 |
