### Hexlet tests and linter status:
[![Actions Status](https://github.com/tatapestova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatapestova/python-project-49/actions)

### Codeclimate maintainability:
<a href="https://codeclimate.com/github/tatapestova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/832bd8344ecad800d99c/maintainability" /></a>

### Demo on asciinema:

| Game | Asciinema |
| ------ | ------ |
| Brain-even | https://asciinema.org/a/y616PGN4pRKfnqF0ZTQNjxF7D |
| Brain-calc | https://asciinema.org/a/xXp3tJDBgyI7dxKdimj2Iqbac |
| Brain-gcd | https://asciinema.org/a/qWjmBlkEwVs5hgYRs6tGPp5ec |
