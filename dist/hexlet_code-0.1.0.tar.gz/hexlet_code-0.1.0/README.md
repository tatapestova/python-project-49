### Hexlet tests and linter status:
[![Actions Status](https://github.com/tatapestova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatapestova/python-project-49/actions)

### Codeclimate maintainability:
<a href="https://codeclimate.com/github/tatapestova/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/832bd8344ecad800d99c/maintainability" /></a>

### Brain-even

[![asciicast](https://asciinema.org/a/y616PGN4pRKfnqF0ZTQNjxF7D.svg)](https://asciinema.org/a/y616PGN4pRKfnqF0ZTQNjxF7D)

### Brain-calc

[![asciicast](https://asciinema.org/a/xXp3tJDBgyI7dxKdimj2Iqbac.svg)](https://asciinema.org/a/xXp3tJDBgyI7dxKdimj2Iqbac)

### Brain-gcd

[![asciicast](https://asciinema.org/a/qWjmBlkEwVs5hgYRs6tGPp5ec.svg)](https://asciinema.org/a/qWjmBlkEwVs5hgYRs6tGPp5ec)

### Brain-progression

[![asciicast](https://https://asciinema.org/a/5aVmWF7SVOjj6ZeeAFR7415EZ.svg)](https://asciinema.org/a/5aVmWF7SVOjj6ZeeAFR7415EZ)

### Brain-prime

[![asciicast](https://asciinema.org/a/dxAPtQutzcdl4NVtGy5MInCC9.svg)](https://asciinema.org/a/dxAPtQutzcdl4NVtGy5MInCC9)
