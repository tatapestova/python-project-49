#!/usr/bin/env python3

import games.logics
import games.game_brain_calc


def main():
    games.game_brain_calc.calc()


if __name__ == '__main__':
    main()