from random import randint, choice
import prompt

def welcome_user():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')

def question():
    print(question)


def finish():
    if user_answer == correct_asnwer:
        print(f'Congratulations, {name}!')
